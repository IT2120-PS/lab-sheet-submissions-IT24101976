setwd("C:\\Users\\jaliy\\Desktop\\IT24101976")

# Uniform distribution between 0 and 40
lower <- 10
upper <- 25
total_range <- 40

prob <- (upper - lower) / total_range
prob

# Exponential distribution with lambda = 1/3
lambda <- 1/3
prob <- pexp(2, rate = lambda)  # P(X ≤ 2)
prob


mean <- 100
sd <- 15

prob_above_130 <- 1 - pnorm(130, mean, sd)
prob_above_130


iq_95th <- qnorm(0.95, mean, sd)
iq_95th

