setwd("C:\\Users\\jaliy\\Downloads\\IT24101976")
getwd()

data<- read.table("Exercise - LaptopsWeights.txt", header = TRUE)

fix(data)

attach(data)
popmn<-mean(Weight.kg.)
popsd<-sd(Weight.kg.)

samples<-c()
n<-c()

for(i in 1:25){
  s<-sample(Weight.kg., 6, replace = TRUE)
  samples<-cbind(samples,s)
  n<-c(n, paste('S', i))
}

colnames(samples)=n
s.means<-apply(samples, 2, mean)
s.sd<-apply(samples, 2, sd)

s.means
s.sd


samplemean<-mean(s.means)
samples_means_sd <- sd(s.means)



popmn
samplemean

truesd <- popsd / sqrt(6)

